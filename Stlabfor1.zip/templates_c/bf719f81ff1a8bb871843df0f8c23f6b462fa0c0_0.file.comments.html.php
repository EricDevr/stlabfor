<?php
/* Smarty version 4.3.0, created on 2023-02-04 22:23:10
  from '/storage/emulated/0/htdocs/Stlabfor1/templates/post/comments.html' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.3.0',
  'unifunc' => 'content_63deccbe5c4e67_94578744',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'bf719f81ff1a8bb871843df0f8c23f6b462fa0c0' => 
    array (
      0 => '/storage/emulated/0/htdocs/Stlabfor1/templates/post/comments.html',
      1 => 1675545787,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_63deccbe5c4e67_94578744 (Smarty_Internal_Template $_smarty_tpl) {
?><section class="comments">
<div class="fb-comments" data-href="http://stlab.online/post/<?php echo $_smarty_tpl->tpl_vars['id']->value;?>
/" data-width="100%" data-numposts="5"></div>
</section><?php }
}
